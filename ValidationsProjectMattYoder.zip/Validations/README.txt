This script was made on Windows.
This script should be run from the home screen.
To run, execute main.py
I am using python 3.4 which uses a different print function than 2.X
Note: The way we are running adb from the script does not allow us to kill it from the script if you are running Windows. You need to hit CTRL^C after my script finishes if you would like for logging to start back up the next time you run the script.
